# MT500-ASSIGNMENT
This assignment we were tasked with analysing and compiling data from unicef with R (posit cloud)
We created a series of world maps, scatter plots, time series charts and bar charts
A story analysing the data has also been included
